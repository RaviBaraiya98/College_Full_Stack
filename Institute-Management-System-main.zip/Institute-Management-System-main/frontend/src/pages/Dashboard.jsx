import Navbar from '@/components/navbar'
import { Separator } from '@/components/ui/separator'
import {
  BookUser,
  DollarSign,
  GraduationCap,
  HelpCircle,
  History,
  Home,
  Mail,
  Phone,
  Plus,
  Settings as SettingsIcon,
  UserCheck,
  Users2,
  X
} from 'lucide-react'
import { useState } from 'react'
import { NavLink, Outlet } from 'react-router-dom'
import { Button } from '../components/ui/button'
import { Transition } from '../components/ui/transition'

const Dashboard = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  const navigation = [
    {
      name: 'Dashboard',
      href: '/dashboard',
      icon: Home,
      description: 'Overview and analytics'
    },
    {
      name: 'Add Course',
      href: '/dashboard/addcourse',
      icon: Plus,
      description: 'Create new courses'
    },
    {
      name: 'All Courses',
      href: '/dashboard/courses',
      icon: BookUser,
      description: 'Manage your courses'
    },
    {
      name: 'Add Student',
      href: '/dashboard/addstudent',
      icon: UserCheck,
      description: 'Enroll new students'
    },
    {
      name: 'All Students',
      href: '/dashboard/students',
      icon: Users2,
      description: 'View all students'
    },
    {
      name: 'Collect Fees',
      href: '/dashboard/collectfees',
      icon: DollarSign,
      description: 'Process payments'
    },
    {
      name: 'Payment History',
      href: '/dashboard/paymenthistory',
      icon: History,
      description: 'View transaction history'
    }
  ]

  const supportLinks = [
    {
      name: 'Help Center',
      href: '/dashboard/help-center',
      icon: HelpCircle,
      description: 'Get help and support'
    },
    {
      name: 'Settings',
      href: '/dashboard/settings',
      icon: SettingsIcon,
      description: 'Manage your preferences'
    }
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="flex h-[calc(100vh-4rem)]">
        {/* Mobile sidebar */}
        <Transition
          show={isMobileMenuOpen}
          enter="transition ease-out duration-200 transform"
          enterFrom="-translate-x-full"
          enterTo="translate-x-0"
          leave="transition ease-in duration-150 transform"
          leaveFrom="translate-x-0"
          leaveTo="-translate-x-full"
        >
          <div className="fixed inset-y-0 left-0 z-50 w-64 bg-background border-r">
            <div className="flex h-16 items-center justify-between px-4">
              <div className="flex items-center space-x-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
                  <GraduationCap className="h-5 w-5 text-primary-foreground" />
                </div>
                <span className="text-lg font-semibold">Institute</span>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <X className="h-5 w-5" />
              </Button>
            </div>

            <nav className="flex flex-1 flex-col">
              <ul role="list" className="flex flex-1 flex-col gap-y-7">
                <li>
                  <div className="text-xs font-semibold leading-6 text-muted-foreground uppercase tracking-wider">
                    Main Navigation
                  </div>
                  <ul role="list" className="-mx-2 mt-2 space-y-1">
                    {navigation.map((item) => (
                      <li key={item.name}>
                        <NavLink
                          to={item.href}
                          end={item.href === '/'}
                          className={({ isActive }) =>
                            `group flex gap-x-3 rounded-md p-2 text-sm leading-6 font-medium transition-all duration-200 ${
                              isActive
                                ? 'bg-primary text-primary-foreground shadow-sm'
                                : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                            }`
                          }
                          onClick={() => setIsMobileMenuOpen(false)}
                        >
                          <item.icon className="h-5 w-5 shrink-0" aria-hidden="true" />
                          <span className="truncate">{item.name}</span>
                        </NavLink>
                      </li>
                    ))}
                  </ul>
                </li>

                <li>
                  <Separator className="my-4" />
                  <div className="text-xs font-semibold leading-6 text-muted-foreground uppercase tracking-wider">
                    Support
                  </div>
                  <ul role="list" className="-mx-2 mt-2 space-y-1">
                    {supportLinks.map((item) => (
                      <li key={item.name}>
                        <NavLink
                          to={item.href}
                          className={({ isActive }) =>
                            `group flex gap-x-3 rounded-md p-2 text-sm leading-6 font-medium transition-all duration-200 ${
                              isActive
                                ? 'bg-primary text-primary-foreground shadow-sm'
                                : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                            }`
                          }
                          onClick={() => setIsMobileMenuOpen(false)}
                        >
                          <item.icon className="h-5 w-5 shrink-0" aria-hidden="true" />
                          <span className="truncate">{item.name}</span>
                        </NavLink>
                      </li>
                    ))}
                  </ul>
                </li>

                {/* Contact Information */}
                <li className="mt-auto">
                  <Separator className="my-4" />
                  <div className="text-xs font-semibold leading-6 text-muted-foreground uppercase tracking-wider mb-2">
                    Contact Support
                  </div>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4" />
                      <span>+91 1234567890</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4" />
                      <span>support@Institute.com</span>
                    </div>
                  </div>
                </li>
              </ul>
            </nav>
          </div>
        </Transition>

        {/* Desktop sidebar */}
        <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 lg:z-50 lg:pt-16">
          <div className="flex grow flex-col gap-y-5 overflow-y-auto border-r bg-background px-6 pb-4">
            {/* Logo */}
            <div className="flex h-16 shrink-0 items-center">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
                <GraduationCap className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="ml-3 text-lg font-semibold">Institute</span>
            </div>

            {/* Navigation */}
            <nav className="flex flex-1 flex-col">
              <ul role="list" className="flex flex-1 flex-col gap-y-7">
                <li>
                  <div className="text-xs font-semibold leading-6 text-muted-foreground uppercase tracking-wider">
                    Main Navigation
                  </div>
                  <ul role="list" className="-mx-2 mt-2 space-y-1">
                    {navigation.map((item) => (
                      <li key={item.name}>
                        <NavLink
                          to={item.href}
                          end={item.href === '/'}
                          className={({ isActive }) =>
                            `group flex gap-x-3 rounded-md p-2 text-sm leading-6 font-medium transition-all duration-200 ${
                              isActive
                                ? 'bg-primary text-primary-foreground shadow-sm'
                                : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                            }`
                          }
                        >
                          <item.icon className="h-5 w-5 shrink-0" aria-hidden="true" />
                          <span className="truncate">{item.name}</span>
                        </NavLink>
                      </li>
                    ))}
                  </ul>
                </li>

                <li>
                  <Separator className="my-4" />
                  <div className="text-xs font-semibold leading-6 text-muted-foreground uppercase tracking-wider">
                    Support
                  </div>
                </li>
                <li className="mt-auto">
                  <Separator className="my-4" />
                  <div className="text-xs font-semibold leading-6 text-muted-foreground uppercase tracking-wider mb-2">
                    Contact Support
                  </div>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4" />
                      <span>+91 1234567890</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4" />
                      <span>support@Institute.com</span>
                    </div>
                  </div>
                </li>
              </ul>
            </nav>
          </div>
        </aside>

        {/* Main content */}
        <main className="flex-1 lg:pl-64">
          <div className="px-4 sm:px-6 lg:px-8 py-8">
            <div className="mx-auto max-w-7xl">
              <Outlet />
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}

export default Dashboard
