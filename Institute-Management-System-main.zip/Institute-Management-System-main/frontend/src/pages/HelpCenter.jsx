import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, BookOpen, Globe, HelpCircle, Mail, Phone, Shield } from "lucide-react"

const HelpCenter = () => {
  const faqs = [
    {
      question: "How do I add a new course?",
      answer: "To add a new course, click on the 'Add Course' button in the sidebar. Fill in the course details including name, description, price, and upload a course image. Click 'Save' to create the course."
    },
    {
      question: "How can I manage student enrollments?",
      answer: "You can manage student enrollments through the 'All Students' section. Here you can view enrolled students, add new students, and manage their course assignments and fees."
    },
    {
      question: "What payment methods are supported?",
      answer: "We currently support online payments through our secure payment gateway. You can also manage offline payments through the 'Collect Fees' section."
    },
    {
      question: "How do I change my password?",
      answer: "You can change your password by going to the Settings page and clicking on the 'Security' tab. From there, you can update your password by following the instructions."
    }
  ]

  return (
    <div className="container py-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Contact Information */}
        <Card>
          <CardHeader>
            <CardTitle>Contact Support</CardTitle>
            <CardDescription>Get in touch with our support team</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <Phone className="h-5 w-5 text-muted-foreground" />
                <div>
                  <h3 className="font-medium">Phone Support</h3>
                  <p className="text-muted-foreground">+91 1234567890</p>
                  <p className="text-xs text-muted-foreground">Mon-Fri, 9AM-5PM</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <Mail className="h-5 w-5 text-muted-foreground" />
                <div>
                  <h3 className="font-medium">Email Support</h3>
                  <p className="text-muted-foreground">support@Institute.com</p>
                  <p className="text-xs text-muted-foreground">24/7 support</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <Globe className="h-5 w-5 text-muted-foreground" />
                <div>
                  <h3 className="font-medium">Online Chat</h3>
                  <p className="text-muted-foreground">Live chat available</p>
                  <p className="text-xs text-muted-foreground">Mon-Fri, 9AM-5PM</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Links */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Links</CardTitle>
            <CardDescription>Common tasks and resources</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Button variant="outline" className="w-full justify-start">
                <BookOpen className="mr-2 h-4 w-4" />
                Course Management
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <HelpCircle className="mr-2 h-4 w-4" />
                Student Help
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Shield className="mr-2 h-4 w-4" />
                Security & Privacy
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <AlertCircle className="mr-2 h-4 w-4" />
                Report an Issue
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* FAQ Section */}
        <Card>
          <CardHeader>
            <CardTitle>Frequently Asked Questions</CardTitle>
            <CardDescription>Common questions and answers</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {faqs.map((faq, index) => (
                <div key={index} className="space-y-2">
                  <h3 className="font-medium">{faq.question}</h3>
                  <p className="text-muted-foreground">{faq.answer}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default HelpCenter
