import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, Edit2, Home, Mail, Phone, Settings as SettingsIcon, Shield } from "lucide-react"
import { useNavigate } from "react-router-dom"

const Profile = () => {
  const navigate = useNavigate()
  
  return (
    <div className="container py-8">
      <Card>
        <CardHeader>
          <CardTitle>Profile Information</CardTitle>
          <CardDescription>Your account and personal information</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-8">
            {/* Profile Header */}
            <div className="flex items-center gap-6">
              <Avatar className="h-24 w-24">
                <AvatarImage src="/default-avatar.png" alt="Profile" />
                <AvatarFallback>CN</AvatarFallback>
              </Avatar>
              <div>
                <h2 className="text-2xl font-semibold">Institute Name</h2>
                <p className="text-muted-foreground">Institute Owner</p>
              </div>
            </div>

            {/* Contact Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex items-center gap-4">
                <Mail className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">Email</p>
                  <p className="text-muted-foreground">email@example.com</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <Phone className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">Phone</p>
                  <p className="text-muted-foreground">+91 1234567890</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <Home className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">Address</p>
                  <p className="text-muted-foreground">123 Education Street, City</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <Calendar className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">Joined</p>
                  <p className="text-muted-foreground">January 1, 2024</p>
                </div>
              </div>
            </div>

            {/* Account Security */}
            <div className="space-y-4">
              <h3 className="font-medium">Account Security</h3>
              <div className="flex items-center gap-4">
                <Shield className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">Last Password Change</p>
                  <p className="text-muted-foreground">30 days ago</p>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-4">
              <Button variant="outline" onClick={() => navigate('/dashboard/settings')}>
                <SettingsIcon className="mr-2 h-4 w-4" />
                Edit Settings
              </Button>
              <Button onClick={() => navigate('/settings/change-password')}>
                <Edit2 className="mr-2 h-4 w-4" />
                Change Password
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Profile
