import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PublicNavbar from '../components/PublicNavbar';

const Home = () => {
  const [displaytext, setDisplayText] = useState('');
  const navigate = useNavigate();
  const fulltext = "Welcome! Manage Your Institute with Ease ";

  // text animation 
  useEffect(() => {
    let index = 0;
    const interval = setInterval(() => {
      if (index < fulltext.length) {
        setDisplayText(fulltext.substring(0, index + 1));
        index++;
      } else {
        clearInterval(interval);
        setTimeout(() => {
          navigate('/login');
        }, 1000);
      }
    }, 100);

    return () => clearInterval(interval);
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <PublicNavbar />
      <div className="flex justify-center items-center h-[calc(100vh-4rem)]">
        <div className="text-center space-y-6">
          <h1 className="text-3xl sm:text-5xl font-bold leading-tight text-foreground max-w-4xl">
            {displaytext}
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl">
            Streamline your institute management with our comprehensive platform
          </p>
          <div className="flex justify-center space-x-4">
            <button 
              onClick={() => navigate('/login')}
              className="px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
            >
              Get Started
            </button>
            <button 
              onClick={() => navigate('/signup')}
              className="px-6 py-3 border border-primary text-primary rounded-lg hover:bg-primary/10 transition-colors"
            >
              Learn More
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Home
