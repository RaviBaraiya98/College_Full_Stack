import { Suspense, useEffect } from 'react'
import { Route, Routes, useLocation } from 'react-router-dom'
import AddCourse from './components/AddCourse'
import AddStudent from './components/AddStudent'
import AllCourses from './components/AllCourses'
import AllStudents from './components/AllStudents'
import CollectFees from './components/CollectFees'
import CourseDetail from './components/CourseDetail'
import DashboardHome from './components/DashboardHome'
import Login from './components/Login'
import PaymentHistory from './components/PaymentHistory'
import Signup from './components/Signup'
import StudentProfile from './components/StudentProfile'
import { ThemeProvider } from './components/ThemeProvider'
import { Toaster } from './components/ui/Toaster'
import Dashboard from './pages/Dashboard'
import ErrorBoundary from './pages/Errorboundary'
import HelpCenter from './pages/HelpCenter'
import Home from './pages/Home'
import Profile from './pages/Profile'
import Settings from './pages/Settings'

function App() {
  const location = useLocation()

  useEffect(() => {
    // Add smooth page transitions
    const handleScroll = () => {
      window.scrollTo(0, 0)
    }
    handleScroll()
  }, [location.pathname])

  return (
    <ThemeProvider>
      <ErrorBoundary>
        <div className="App">
          <Suspense fallback={<LoadingScreen />}>
            <Routes>
              {/* Public Routes */}
              <Route path="/" element={<Home />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              
              {/* Protected Dashboard Routes */}
              <Route path="/dashboard" element={<Dashboard />}>
                <Route index element={<DashboardHome />} />
                <Route path="addcourse" element={<AddCourse />} />
                <Route path="courses" element={<AllCourses />} />
                <Route path="courses/:id" element={<CourseDetail />} />
                <Route path="addstudent" element={<AddStudent />} />
                <Route path="students" element={<AllStudents />} />
                <Route path="students/:id" element={<StudentProfile />} />
                <Route path="collectfees" element={<CollectFees />} />
                <Route path="paymenthistory" element={<PaymentHistory />} />
                <Route path="profile" element={<Profile />} />
                <Route path="settings" element={<Settings />} />
                <Route path="help-center" element={<HelpCenter />} />
              </Route>
            </Routes>
          </Suspense>
          <Toaster />
        </div>
      </ErrorBoundary>
    </ThemeProvider>
  )
}

const LoadingScreen = () => (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/95">
    <div className="flex flex-col items-center gap-4">
      <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      <p className="text-muted-foreground">Loading...</p>
    </div>
  </div>
)

export default App
