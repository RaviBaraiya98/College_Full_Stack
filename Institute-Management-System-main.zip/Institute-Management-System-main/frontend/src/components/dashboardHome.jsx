
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import axios from "axios";
import { Activity, BookOpen, DollarSign, Eye, History, Loader2, Plus, TrendingDown, TrendingUp, UserCheck, Users } from "lucide-react";
import { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";

function DashboardHome() {
  const [loading, setloading] = useState(false);
  const [studentinfo, setStudentinfo] = useState([]);
  const [coursecount, setCoursecount] = useState([]);
  const [feescount, setFeescount] = useState(0);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [coursesRes, studentsRes, totalAmountRes] = await Promise.all([
          axios.get(`${import.meta.env.VITE_BACKEND_URL}/course/allcourses`, { withCredentials: true }),
          axios.get(`${import.meta.env.VITE_BACKEND_URL}/student/allstudents`, { withCredentials: true }),
          axios.get(`${import.meta.env.VITE_BACKEND_URL}/fees/totalamount`, { withCredentials: true })
        ]);
        if (coursesRes.data) {
          setCoursecount(coursesRes.data.Courses);
        }
        if (studentsRes.data) {
          setStudentinfo(studentsRes.data.students);
        }
        if (totalAmountRes.data) {
          setFeescount(totalAmountRes.data.totalamount);
        }
      } catch (error) {
        console.log(error?.response?.data?.message);
      }
    };
    fetchData();
  }, []);

  useEffect(() => {
    const fetchStudents = async () => {
      try {
        setloading(true);
        const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/student/allstudents`, { withCredentials: true });
        if (response.data) {
          setStudentinfo(response.data.students);
        }
      } catch (error) {
        console.error(error?.response?.data?.message);
      } finally {
        setTimeout(() => {
          setloading(false);
        }, 1000);
      }
    };
    fetchStudents();
  }, []);

  useEffect(() => {
    const fetchTotalAmount = async () => {
      try {
        const res = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/fees/totalamount`, { withCredentials: true });
        if (res.data) {
          setFeescount(res.data.totalamount);
        }
      } catch (error) {
        console.log(error?.response?.data?.message || "Something went wrong");
      }
    };
    fetchTotalAmount();
  }, []);

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">
          Welcome back! Here's what's happening with your institute today.
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          title="Total Students"
          value={studentinfo?.length || "0"}
          icon={<Users className="h-4 w-4" />}
          description="Active enrollments"
          trend="+12%"
          trendDirection="up"
        />
        <MetricCard
          title="Total Courses"
          value={coursecount?.length || "0"}
          icon={<BookOpen className="h-4 w-4" />}
          description="Available courses"
          trend="+5%"
          trendDirection="up"
        />
        <MetricCard
          title="Total Revenue"
          value={formatCurrency(feescount || 0)}
          icon={<DollarSign className="h-4 w-4" />}
          description="This month"
          trend="+23%"
          trendDirection="up"
        />
        <MetricCard
          title="Active Sessions"
          value="24"
          icon={<Activity className="h-4 w-4" />}
          description="Ongoing classes"
          trend="+8%"
          trendDirection="up"
        />
      </div>

      {/* Recent Students */}
      <Card className="card-hover">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Recent Students</CardTitle>
              <CardDescription>
                Latest student enrollments and their details
              </CardDescription>
            </div>
            <NavLink to="/students">
              <Button variant="outline" size="sm">
                View All
              </Button>
            </NavLink>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : studentinfo.length > 0 ? (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {studentinfo.slice(0, 6).map((student) => (
                  <div
                    key={student._id}
                    className="flex items-center space-x-4 p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                  >
                    <Avatar className="h-10 w-10">
                      <AvatarImage
                        src={student?.profilePicture || "/default-avatar.png"}
                        alt={student?.name}
                      />
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {student?.name?.charAt(0)?.toUpperCase() || "S"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium leading-none truncate">
                        {student?.name}
                      </p>
                      <p className="text-sm text-muted-foreground truncate">
                        {student?.email}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="secondary" className="text-xs">
                          {typeof student?.coursename === 'object'
                            ? (student?.coursename?.name || 'Course')
                            : (student?.coursename || 'Course')}
                        </Badge>
                      </div>
                    </div>
                    <NavLink to={`/students/${student._id}`}>
                      <Button variant="ghost" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                    </NavLink>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <Users className="mx-auto h-12 w-12 text-muted-foreground" />
              <h3 className="mt-2 text-sm font-semibold text-foreground">No students</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                Get started by adding your first student.
              </p>
              <div className="mt-6">
                <NavLink to="/addstudent">
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Student
                  </Button>
                </NavLink>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="card-hover cursor-pointer">
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <div className="p-2 rounded-lg bg-primary/10">
                <Plus className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="text-sm font-medium">Add Course</p>
                <p className="text-xs text-muted-foreground">Create new course</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="card-hover cursor-pointer">
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <div className="p-2 rounded-lg bg-green-500/10">
                <UserCheck className="h-4 w-4 text-green-500" />
              </div>
              <div>
                <p className="text-sm font-medium">Add Student</p>
                <p className="text-xs text-muted-foreground">Enroll new student</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="card-hover cursor-pointer">
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <div className="p-2 rounded-lg bg-blue-500/10">
                <DollarSign className="h-4 w-4 text-blue-500" />
              </div>
              <div>
                <p className="text-sm font-medium">Collect Fees</p>
                <p className="text-xs text-muted-foreground">Process payment</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="card-hover cursor-pointer">
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <div className="p-2 rounded-lg bg-purple-500/10">
                <History className="h-4 w-4 text-purple-500" />
              </div>
              <div>
                <p className="text-sm font-medium">View Reports</p>
                <p className="text-xs text-muted-foreground">Analytics & insights</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default DashboardHome;

function MetricCard({ title, value, icon, description, trend, trendDirection }) {
  return (
    <Card className="card-hover">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <div className="h-4 w-4 text-muted-foreground">{icon}</div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <div className="flex items-center space-x-2 text-xs text-muted-foreground">
          <span>{description}</span>
          {trend && (
            <div className={`flex items-center ${trendDirection === 'up' ? 'text-green-600' : 'text-red-600'}`}>
              {trendDirection === 'up' ? (
                <TrendingUp className="h-3 w-3" />
              ) : (
                <TrendingDown className="h-3 w-3" />
              )}
              <span>{trend}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
