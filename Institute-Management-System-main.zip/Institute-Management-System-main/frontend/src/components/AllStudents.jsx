import axios from 'axios'
import { Eye, Loader2, Mail, MapPin, Phone, Plus, Search, Users } from 'lucide-react'
import { useEffect, useState } from 'react'
import { NavLink } from 'react-router-dom'
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar'
import { Badge } from './ui/badge'
import { Button } from './ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card'
import { Input } from './ui/input'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table'

const AllStudents = () => {
  const [studentinfo, setStudentinfo] = useState([])
  const [filteredStudents, setFilteredStudents] = useState([])
  const [loading, setloading] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')

  useEffect(() => {
    const fetchStudents = async () => {
      try {
        setloading(true)
        const res = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/student/allstudents`, { withCredentials: true });
        if (res.data) {
          setStudentinfo(res.data.students);
          setFilteredStudents(res.data.students)
        }
      } catch (error) {
        console.log(error?.response?.data?.message);
      } finally {
        setTimeout(() => {
          setloading(false)
        }, 1000);
      }
    }
    fetchStudents()
  }, [])

  // Filter students based on search term
  useEffect(() => {
    const filtered = studentinfo.filter(student =>
      student.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.phone?.includes(searchTerm) ||
      student.coursename?.toLowerCase().includes(searchTerm.toLowerCase())
    )
    setFilteredStudents(filtered)
  }, [searchTerm, studentinfo])

  const getInitials = (name) => {
    if (!name) return 'S';
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold tracking-tight">All Students</h1>
          <p className="text-muted-foreground">
            Manage and view all enrolled students in your institute.
          </p>
        </div>
        <NavLink to="/addstudent">
          <Button className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Add Student
          </Button>
        </NavLink>
      </div>

      {/* Stats Card */}
      <Card className="card-hover">
        <CardContent className="p-6">
          <div className="flex items-center space-x-4">
            <div className="p-2 rounded-lg bg-primary/10">
              <Users className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold">{studentinfo.length}</p>
              <p className="text-sm text-muted-foreground">Total Students</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Search and Filters */}
      <Card className="card-hover">
        <CardHeader>
          <CardTitle>Search Students</CardTitle>
          <CardDescription>
            Find students by name, email, phone, or course
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search students..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Students Table */}
      <Card className="card-hover">
        <CardHeader>
          <CardTitle>Student Directory</CardTitle>
          <CardDescription>
            {filteredStudents.length} of {studentinfo.length} students
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : filteredStudents.length > 0 ? (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[60px]">Photo</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Course</TableHead>
                    <TableHead className="hidden md:table-cell">Contact</TableHead>
                    <TableHead className="hidden lg:table-cell">Address</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStudents.map((student) => (
                    <TableRow key={student._id} className="hover:bg-accent/50">
                      <TableCell>
                        <Avatar className="h-10 w-10">
                          <AvatarImage
                            src={student?.profilePicture || "/default-avatar.png"}
                            alt={student?.name}
                          />
                          <AvatarFallback className="bg-primary text-primary-foreground">
                            {getInitials(student?.name)}
                          </AvatarFallback>
                        </Avatar>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium">{student?.name}</p>
                          <p className="text-sm text-muted-foreground">{student?.email}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="text-xs">
                          {typeof student?.coursename === 'object'
                            ? (student?.coursename?.name || 'Not Assigned')
                            : (student?.coursename || 'Not Assigned')}
                        </Badge>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        <div className="space-y-1">
                          <div className="flex items-center gap-1 text-sm">
                            <Phone className="h-3 w-3" />
                            <span>{student?.phone}</span>
                          </div>
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            <Mail className="h-3 w-3" />
                            <span>{student?.email}</span>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="hidden lg:table-cell">
                        <div className="flex items-center gap-1 text-sm text-muted-foreground max-w-[200px]">
                          <MapPin className="h-3 w-3 flex-shrink-0" />
                          <span className="truncate">{student?.address}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <NavLink to={`/students/${student._id}`}>
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </NavLink>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-12">
              <Users className="mx-auto h-12 w-12 text-muted-foreground" />
              <h3 className="mt-2 text-sm font-semibold text-foreground">
                {searchTerm ? 'No students found' : 'No students yet'}
              </h3>
              <p className="mt-1 text-sm text-muted-foreground">
                {searchTerm 
                  ? 'Try adjusting your search terms.'
                  : 'Get started by adding your first student.'
                }
              </p>
              {!searchTerm && (
                <div className="mt-6">
                  <NavLink to="/addstudent">
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Student
                    </Button>
                  </NavLink>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default AllStudents
