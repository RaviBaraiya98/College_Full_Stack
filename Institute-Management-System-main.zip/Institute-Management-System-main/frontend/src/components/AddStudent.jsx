import axios from 'axios';
import { BookOpen, Camera, Loader2, Mail, MapPin, Phone, Upload, User } from 'lucide-react';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { toast } from 'sonner';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';

const AddStudent = () => {
  const [loading, setloading] = useState(false)
  const [previewImage, setPreviewImage] = useState(null)
  const { register, handleSubmit, setValue, trigger, reset, formState: { errors } } = useForm();

  const onSubmit = async (data) => {
    const formdata = new FormData();
    formdata.append("name", data.name);
    formdata.append("email", data.email);
    formdata.append("phone", data.phone);
    formdata.append("address", data.address);
    formdata.append("coursename", data.coursename);

    if (data.profilePicture?.length > 0) {
      formdata.append("profilePicture", data.profilePicture[0]);
    }
       
    try {
      setloading(true)
      const response = await axios.post(`${import.meta.env.VITE_BACKEND_URL}/student/addstudent`, formdata, {
        headers: { "Content-Type": "multipart/form-data" }, 
        withCredentials: true
      })
      toast.success(response.data?.message || "Student added successfully")
      reset()
      setPreviewImage(null)
    } catch (error) {
      console.log(error);
      toast.error(error.response?.data?.message || "Something went wrong")
    } finally {
      setloading(false);
    }
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setValue("profilePicture", file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result);
      };
      reader.readAsDataURL(file);
    }
    trigger("profilePicture");
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="space-y-6">
        {/* Header */}
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">Add New Student</h1>
          <p className="text-muted-foreground">
            Enroll a new student by filling out the information below.
          </p>
        </div>

        <Card className="card-hover">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Student Information
            </CardTitle>
            <CardDescription>
              Enter the student's personal and course details
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              {/* Profile Picture Upload */}
              <div className="space-y-4">
                <Label htmlFor="profilePicture">Profile Picture</Label>
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <Avatar className="h-20 w-20">
                      <AvatarImage src={previewImage} alt="Profile preview" />
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        <Camera className="h-6 w-6" />
                      </AvatarFallback>
                    </Avatar>
                  </div>
                  <div className="flex-1">
                    <Input
                      id="profilePicture"
                      type="file"
                      accept="image/*"
                      onChange={handleImageChange}
                      className="hidden"
                      {...register("profilePicture", { required: true })}
                    />
                    <Label
                      htmlFor="profilePicture"
                      className="cursor-pointer inline-flex items-center gap-2 px-4 py-2 border border-dashed border-muted-foreground/25 rounded-lg hover:bg-accent hover:text-accent-foreground transition-colors"
                    >
                      <Upload className="h-4 w-4" />
                      <span>Upload Photo</span>
                    </Label>
                    {errors.profilePicture && (
                      <p className="text-sm text-destructive mt-1">Profile picture is required</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Personal Information */}
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="name" className="flex items-center gap-2">
                    <User className="h-4 w-4" />
                    Full Name
                  </Label>
                  <Input
                    id="name"
                    type="text"
                    placeholder="Enter student's full name"
                    className="w-full"
                    {...register("name", { required: true })}
                  />
                  {errors.name && (
                    <p className="text-sm text-destructive">Name is required</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="flex items-center gap-2">
                    <Mail className="h-4 w-4" />
                    Email Address
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter email address"
                    className="w-full"
                    {...register("email", { required: true })}
                  />
                  {errors.email && (
                    <p className="text-sm text-destructive">Email is required</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone" className="flex items-center gap-2">
                    <Phone className="h-4 w-4" />
                    Phone Number
                  </Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="Enter phone number"
                    className="w-full"
                    {...register("phone", { required: true })}
                  />
                  {errors.phone && (
                    <p className="text-sm text-destructive">Phone number is required</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="coursename" className="flex items-center gap-2">
                    <BookOpen className="h-4 w-4" />
                    Course Name
                  </Label>
                  <Input
                    id="coursename"
                    type="text"
                    placeholder="Enter course name"
                    className="w-full"
                    {...register("coursename", { required: true })}
                  />
                  {errors.coursename && (
                    <p className="text-sm text-destructive">Course name is required</p>
                  )}
                </div>
              </div>

              {/* Address */}
              <div className="space-y-2">
                <Label htmlFor="address" className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  Address
                </Label>
                <Input
                  id="address"
                  type="text"
                  placeholder="Enter complete address"
                  className="w-full"
                  {...register("address", { required: true })}
                />
                {errors.address && (
                  <p className="text-sm text-destructive">Address is required</p>
                )}
              </div>

              {/* Submit Button */}
              <div className="flex justify-end">
                <Button type="submit" disabled={loading} className="min-w-[120px]">
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Adding...
                    </>
                  ) : (
                    <>
                      <User className="mr-2 h-4 w-4" />
                      Add Student
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default AddStudent
