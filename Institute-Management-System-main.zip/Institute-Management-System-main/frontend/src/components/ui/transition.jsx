import React, { useState } from 'react'

export function Transition({ show, children, ...props }) {
  const [isExiting, setIsExiting] = useState(false)

  if (!show && !isExiting) {
    return null
  }

  return (
    <div
      {...props}
      className={`transition-opacity duration-200 ${
        show
          ? 'opacity-100'
          : 'opacity-0'
      }`}
      onAnimationEnd={() => {
        if (!show) {
          setIsExiting(true)
        }
      }}
    >
      {children}
    </div>
  )
}
