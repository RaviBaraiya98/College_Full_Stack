import axios from 'axios'
import { BookOpen, Camera, Clock, DollarSign, FileText, Loader2, Upload } from 'lucide-react'
import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { toast } from 'sonner'
import { Button } from './ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card'
import { Input } from './ui/input'
import { Label } from './ui/label'
import { Textarea } from './ui/textarea'

const AddCourse = () => {
  const { register, handleSubmit, reset, setValue, trigger, formState: { errors } } = useForm();
  const [loading, setloading] = useState(false)
  const [previewImage, setPreviewImage] = useState(null)

  const onSubmit = async (data) => {
    const formdata = new FormData();
    formdata.append("name", data.name);
    formdata.append("description", data.description);
    formdata.append("price", data.price);
    formdata.append("duration", data.duration);

    if (data.image?.length > 0) {
      formdata.append("image", data.image[0]);
    }

    try {
      setloading(true)
      const response = await axios.post(`${import.meta.env.VITE_BACKEND_URL}/course/addcourse`, formdata, {
        headers: { "Content-Type": "multipart/form-data" },
        withCredentials: true
      })
      console.log("response", response.data.Course);
      toast.success(response.data?.message || "Course added successfully")
      reset()
      setPreviewImage(null)
    } catch (error) {
      console.log(error);
      toast.error(error.response?.data?.message || "Something went wrong")
    } finally {
      setloading(false);
    }
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setValue("image", file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result);
      };
      reader.readAsDataURL(file);
    }
    trigger("image");
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="space-y-6">
        {/* Header */}
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">Add New Course</h1>
          <p className="text-muted-foreground">
            Create a new course by filling out the information below.
          </p>
        </div>

        <Card className="card-hover">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5" />
              Course Information
            </CardTitle>
            <CardDescription>
              Enter the course details and upload an image
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              {/* Course Image Upload */}
              <div className="space-y-4">
                <Label htmlFor="image">Course Image</Label>
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    {previewImage ? (
                      <div className="h-24 w-24 rounded-lg border-2 border-dashed border-muted-foreground/25 overflow-hidden">
                        <img
                          src={previewImage}
                          alt="Course preview"
                          className="h-full w-full object-cover"
                        />
                      </div>
                    ) : (
                      <div className="h-24 w-24 rounded-lg border-2 border-dashed border-muted-foreground/25 flex items-center justify-center bg-muted/50">
                        <Camera className="h-8 w-8 text-muted-foreground" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <Input
                      id="image"
                      type="file"
                      accept="image/*"
                      onChange={handleImageChange}
                      className="hidden"
                      {...register("image", { required: true })}
                    />
                    <Label
                      htmlFor="image"
                      className="cursor-pointer inline-flex items-center gap-2 px-4 py-2 border border-dashed border-muted-foreground/25 rounded-lg hover:bg-accent hover:text-accent-foreground transition-colors"
                    >
                      <Upload className="h-4 w-4" />
                      <span>Upload Image</span>
                    </Label>
                    {errors.image && (
                      <p className="text-sm text-destructive mt-1">Course image is required</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Course Details */}
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="name" className="flex items-center gap-2">
                    <BookOpen className="h-4 w-4" />
                    Course Name
                  </Label>
                  <Input
                    id="name"
                    type="text"
                    placeholder="Enter course name"
                    className="w-full"
                    {...register("name", { required: true })}
                  />
                  {errors.name && (
                    <p className="text-sm text-destructive">Course name is required</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="price" className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4" />
                    Course Price
                  </Label>
                  <Input
                    id="price"
                    type="number"
                    placeholder="Enter course price"
                    className="w-full"
                    {...register("price", { required: true })}
                  />
                  {errors.price && (
                    <p className="text-sm text-destructive">Price is required</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="duration" className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    Duration
                  </Label>
                  <Input
                    id="duration"
                    type="text"
                    placeholder="e.g., 3 months, 6 weeks"
                    className="w-full"
                    {...register("duration", { required: true })}
                  />
                  {errors.duration && (
                    <p className="text-sm text-destructive">Duration is required</p>
                  )}
                </div>
              </div>

              {/* Description */}
              <div className="space-y-2">
                <Label htmlFor="description" className="flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Description
                </Label>
                <Textarea
                  id="description"
                  placeholder="Enter detailed course description..."
                  className="min-h-[120px]"
                  {...register("description", { required: true })}
                />
                {errors.description && (
                  <p className="text-sm text-destructive">Description is required</p>
                )}
              </div>

              {/* Submit Button */}
              <div className="flex justify-end">
                <Button type="submit" disabled={loading} className="min-w-[120px]">
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Adding...
                    </>
                  ) : (
                    <>
                      <BookOpen className="mr-2 h-4 w-4" />
                      Add Course
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default AddCourse
