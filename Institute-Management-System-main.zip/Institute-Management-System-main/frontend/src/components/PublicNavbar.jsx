import { Chrome, LogIn, UserPlus } from 'lucide-react';
import { NavLink } from 'react-router-dom';
import { ThemeToggle } from './ThemeToggle';
import { Button } from './ui/button';

const PublicNavbar = () => {
  const handleGoogleLogin = () => {
    window.location.href = `${import.meta.env.VITE_BACKEND_URL}/auth/google`;
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4">
        {/* Logo */}
        <div className="flex items-center space-x-2">
          <NavLink to="/" className="flex items-center space-x-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <span className="text-sm font-bold text-primary-foreground">E</span>
            </div>
            <span className="hidden font-bold sm:inline-block text-xl">
              Institute
            </span>
          </NavLink>
        </div>

        {/* Right side */}
        <div className="flex items-center space-x-4">
          {/* Theme Toggle */}
          <ThemeToggle />

          {/* Google OAuth Button */}
          <Button 
            onClick={handleGoogleLogin}
            variant="outline" 
            size="sm"
            className="hidden sm:flex items-center gap-2"
          >
            <Chrome className="h-4 w-4" />
            Sign in with Google
          </Button>

          {/* Login/Signup Buttons */}
          <div className="flex items-center space-x-2">
            <NavLink to="/login">
              <Button variant="ghost" size="sm" className="flex items-center gap-2">
                <LogIn className="h-4 w-4" />
                <span className="hidden sm:inline">Sign In</span>
              </Button>
            </NavLink>
            <NavLink to="/signup">
              <Button size="sm" className="flex items-center gap-2">
                <UserPlus className="h-4 w-4" />
                <span className="hidden sm:inline">Sign Up</span>
              </Button>
            </NavLink>
          </div>
        </div>
      </div>
    </header>
  );
};

export default PublicNavbar; 