import passport from 'passport';
import { Strategy as GoogleStrategy } from 'passport-google-oauth20';
import Owner from '../models/OwnerModal.js';

// Serialize user for the session
passport.serializeUser((user, done) => {
    done(null, user.id);
});

// Deserialize user from the session
passport.deserializeUser(async (id, done) => {
    try {
        const user = await Owner.findById(id);
        done(null, user);
    } catch (error) {
        done(error, null);
    }
});

// Google OAuth Strategy
passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: "/auth/google/callback", // Relative URL - resolves to backend port
    scope: ['profile', 'email']
}, async (accessToken, refreshToken, profile, done) => {
    try {
        // Check if user already exists
        let user = await Owner.findOne({ 
            $or: [
                { googleId: profile.id },
                { email: profile.emails[0].value }
            ]
        });

        if (user) {
            // Update existing user with Google info if not already set
            if (!user.googleId) {
                user.googleId = profile.id;
                user.googleEmail = profile.emails[0].value;
                user.googleName = profile.displayName;
                user.googlePicture = profile.photos[0]?.value;
                user.authProvider = 'google';
                await user.save();
            }
        } else {
            // Create new user
            user = await Owner.create({
                insitiutename: profile.displayName,
                email: profile.emails[0].value,
                googleId: profile.id,
                googleEmail: profile.emails[0].value,
                googleName: profile.displayName,
                googlePicture: profile.photos[0]?.value,
                authProvider: 'google'
            });
        }

        return done(null, user);
    } catch (error) {
        console.error('Google OAuth error:', error);
        return done(error, null);
    }
}));

export default passport; 