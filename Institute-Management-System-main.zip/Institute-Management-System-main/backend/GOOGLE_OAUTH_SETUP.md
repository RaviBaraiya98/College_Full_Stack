# Google OAuth 2.0 Setup Guide

## Environment Variables Required

Add these variables to your `.env` file:

```env
# Google OAuth
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret

# Session (if not already set)
SESSION_SECRET=your_session_secret_key
```

## Google OAuth Setup Steps

### 1. Create Google OAuth Credentials

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select an existing one
3. Enable the Google+ API
4. Go to "Credentials" → "Create Credentials" → "OAuth 2.0 Client IDs"
5. Choose "Web application"
6. Set the following:
   - **Authorized JavaScript origins**: `http://localhost:5173`
   - **Authorized redirect URIs**: `http://localhost:5000/auth/google/callback`
7. Copy the Client ID and Client Secret

### 2. Update Your .env File

```env
GOOGLE_CLIENT_ID=your_client_id_here
GOOGLE_CLIENT_SECRET=your_client_secret_here
SESSION_SECRET=your_session_secret_here
```

## API Endpoints

### Google OAuth Routes

- `GET /auth/google` - Initiate Google OAuth login
- `GET /auth/google/callback` - Google OAuth callback (handles token creation)
- `GET /auth/status` - Check authentication status

### Existing Routes (Unchanged)

- `POST /user/signup` - Local signup
- `POST /user/login` - Local login
- `GET /user/logout` - Logout
- `GET /user/profile` - Get user profile (protected)

## How It Works

1. **User clicks "Sign in with Google"** → Redirects to `/auth/google`
2. **Google OAuth flow** → User authenticates with Google
3. **Callback** → `/auth/google/callback` receives user data
4. **User creation/update** → Creates or updates user in MongoDB
5. **JWT token creation** → Signs JWT and sets as HTTP-only cookie
6. **Redirect to frontend** → User is redirected to dashboard

## Database Schema Updates

The `Owner` model now includes these additional fields:

```javascript
{
  // Existing fields
  insitiutename: String,
  email: String,
  password: String, // Now optional for Google users
  
  // New Google OAuth fields
  googleId: String,
  googleEmail: String,
  googleName: String,
  googlePicture: String,
  authProvider: String, // 'local' or 'google'
  
  // Timestamps
  createdAt: Date,
  updatedAt: Date
}
```

## Security Features

- **HTTP-only cookies** for JWT storage
- **Session management** for Passport
- **Backward compatibility** with existing local authentication
- **Protected routes** using existing `isAuthenticated` middleware

## Testing

1. Start the backend server: `npm run dev`
2. Visit `http://localhost:5000/auth/google` in browser
3. Complete Google OAuth flow
4. Check that user is created in MongoDB
5. Verify JWT token is set in cookies
6. Test protected routes with the token 