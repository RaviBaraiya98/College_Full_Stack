import mongoose from "mongoose";

const ownerSchema = mongoose.Schema({
    insitiutename: {type:String,required:true},
    email: {type:String,required:true},
    password: {type:String,required:false}, // Made optional for Google OAuth users
    googleId: {type:String,required:false}, // Google OAuth ID
    googleEmail: {type:String,required:false}, // Google email
    googleName: {type:String,required:false}, // Google display name
    googlePicture: {type:String,required:false}, // Google profile picture
    authProvider: {type:String,enum:['local','google'],default:'local'}, // Track auth method
}, {
    timestamps: true // Add timestamps for better tracking
})

const Owner = mongoose.model("Owner",ownerSchema);
export default Owner



