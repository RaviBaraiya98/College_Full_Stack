import express from "express";
import { Login, Logout, SignUp, getProfile } from "../controllers/UserController.js";
import { isAuthenticated } from "../middleware/isAuthenticated.js";

const router = express.Router();

router.post("/signup",SignUp);
router.post("/login",Login);
router.get("/logout",Logout);
router.get("/profile", isAuthenticated, getProfile);

export default router