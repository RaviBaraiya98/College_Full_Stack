import express from "express";
import jwt from "jsonwebtoken";
import passport from "passport";

const router = express.Router();

// Google OAuth routes
router.get("/google", passport.authenticate("google", { scope: ["profile", "email"] }));

router.get("/google/callback", 
    passport.authenticate("google", { 
        failureRedirect: "http://localhost:5173/login",
        session: false 
    }), 
    (req, res) => {
        try {
            // Create JWT token
            const token = jwt.sign(
                { id: req.user._id }, 
                process.env.JWT_SECRET, 
                { expiresIn: "1d" }
            );

            // Set JWT token in HTTP-only cookie
            res.cookie("token", token, {
                httpOnly: true,
                secure: false, // Set to true in production with HTTPS
                sameSite: "lax",
                maxAge: 24 * 60 * 60 * 1000 // 1 day
            });

            // Redirect to frontend dashboard
            res.redirect("http://localhost:5173/dashboard");
        } catch (error) {
            console.error("Google OAuth callback error:", error);
            res.redirect("http://localhost:5173/login?error=oauth_failed");
        }
    }
);

// Check if user is authenticated
router.get("/status", (req, res) => {
    try {
        const token = req.cookies.token;
        
        if (!token) {
            return res.status(401).json({ 
                isAuthenticated: false, 
                message: "No token found" 
            });
        }

        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        res.status(200).json({ 
            isAuthenticated: true, 
            userId: decoded.id 
        });
    } catch (error) {
        res.status(401).json({ 
            isAuthenticated: false, 
            message: "Invalid token" 
        });
    }
});

export default router; 