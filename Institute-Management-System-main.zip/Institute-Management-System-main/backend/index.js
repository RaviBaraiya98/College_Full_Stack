import cookieParser from "cookie-parser";
import cors from "cors";
import dotenv from "dotenv";
import express from "express";
import session from "express-session";
import mongoose from "mongoose";
import passport from "passport";
import { removespaces } from "./middleware/removespaces.js";
import CourseRoute from "./routes/CourseRoute.js";
import StudentRoute from "./routes/StudentRoute.js";
import UserRoute from "./routes/UserRoute.js";
import AuthRoute from "./routes/authRoute.js";
import FeesRoute from "./routes/feeRoute.js";

// Load environment variables first
dotenv.config()

// Import passport config after environment variables are loaded
import "./config/passport.js";

const app = express();

const PORT = process.env.PORT || 5000;

// middlewares //
app.use(express.json());
app.use(cors({
    origin: "http://localhost:5173",
    credentials:true   
}));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Session middleware for Passport
app.use(session({
    secret: process.env.SESSION_SECRET || 'your-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: false, // Set to true in production with HTTPS
        maxAge: 24 * 60 * 60 * 1000 // 1 day
    }
}));

// Initialize Passport
app.use(passport.initialize());
app.use(passport.session());

// for removing spaces from url
app.use(removespaces);

// routes //
app.use("/user",UserRoute);
app.use("/course",CourseRoute);
app.use("/student",StudentRoute);
app.use("/fees",FeesRoute);
app.use("/auth",AuthRoute);

// connet to db
mongoose.connect(process.env.MONGO_URL).then(()=>{
    console.log("Connected to DB");
}).catch((err)=>{
    console.log("Error connecting to DB",err);
})

app.listen(PORT,()=>{
    console.log(`Server is running on port ${PORT}`);
})

